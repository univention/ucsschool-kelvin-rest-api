# SPDX-License-Identifier: AGPL-3.0-only
# SPDX-FileCopyrightText: 2026 Univention GmbH

"""Types shared between CCF and its Python callbacks.

CCF embeds this file and registers it as the module ``ccf`` before it imports
the connector module, so ``from ccf import CallbackResult`` works in the
container without installing anything. The connector module registers its
functions with ``@register.callback`` (and optionally ``@register.setup`` /
``@register.shutdown``). Install the same file (``pip install ./python``
from the CCF repository) to import it in unit tests outside CCF.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Callable, ClassVar, Protocol, TypedDict, TypeVar

__version__ = "0.1.1"

__all__ = ["CallbackResult", "CcfDatabaseError", "Consumer", "Old", "Relation", "Registry", "Task", "register"]


class CcfDatabaseError(OSError):
    """A read of CCF's own database failed.

    Not the callback's fault: if it escapes ``run``, the task is retried
    without counting an error. A subclass of ``OSError`` (= ``IOError``).
    """


@dataclass(frozen=True, slots=True)
class CallbackResult:
    """The result of one ``run`` call; build it with the class members below.

    Instances compare by value, so a unit test can assert
    ``run(consumer, task) == CallbackResult.SuccessModified()``.
    """

    # The variant name (``SuccessCreated``, ``Failure``, ...); CCF reads it
    # together with the fields below.
    kind: str
    lookup_fields: dict[str, str] | None = None
    msg: str | None = None
    delay: int | None = None

    SuccessDeleted: ClassVar[CallbackResult]
    SuccessSkipped: ClassVar[CallbackResult]

    @classmethod
    def SuccessCreated(cls, lookup_fields: dict[str, str] | None = None) -> CallbackResult:
        """The object was created in the target; stores ``lookup_fields`` (str values)."""
        return cls("SuccessCreated", lookup_fields=_checked_lookup_fields(lookup_fields))

    @classmethod
    def SuccessModified(cls, lookup_fields: dict[str, str] | None = None) -> CallbackResult:
        """The object was updated in the target; stores ``lookup_fields`` (str values)."""
        return cls("SuccessModified", lookup_fields=_checked_lookup_fields(lookup_fields))

    @classmethod
    def Reschedule(cls, delay: int | None = None) -> CallbackResult:
        """Run the task again after ``delay`` seconds (default 0); no error is counted."""
        return cls("Reschedule", delay=_checked_optional(delay, int, "delay"))

    @classmethod
    def Failure(cls, msg: str | None = None, delay: int | None = None) -> CallbackResult:
        """The task failed; it is retried after ``delay`` seconds or moved to the morgue."""
        return cls("Failure", msg=_checked_optional(msg, str, "msg"), delay=_checked_optional(delay, int, "delay"))


CallbackResult.SuccessDeleted = CallbackResult("SuccessDeleted")
CallbackResult.SuccessSkipped = CallbackResult("SuccessSkipped")


# A copy of `fields`, so a later change of the caller's dict does not change
# the result. Raises TypeError unless every key and value is a str.
def _checked_lookup_fields(fields: dict[str, str] | None) -> dict[str, str] | None:
    if fields is None:
        return None
    if not isinstance(fields, dict):
        raise TypeError(f"lookup_fields must be a dict of str, not {type(fields).__name__}")
    for key, value in fields.items():
        if not isinstance(key, str) or not isinstance(value, str):
            raise TypeError(f"lookup_fields must map str to str, got {key!r}: {value!r}")
    return dict(fields)


# `value` unchanged if it is None or of type `kind` (bool is no int here);
# raises TypeError otherwise.
def _checked_optional(value: Any, kind: type, name: str) -> Any:
    if value is None or (isinstance(value, kind) and not isinstance(value, bool)):
        return value
    raise TypeError(f"{name} must be {kind.__name__} or None, not {type(value).__name__}")


class Task(TypedDict):
    """The ``task`` dict passed to ``run``; a fresh dict per call."""

    id: int
    obj_id: str
    udm_module: str
    dn: str
    # The object's attributes; empty for a Delete. Changes are stored with a
    # Success/Reschedule result.
    attrs: dict[str, Any]
    status: str
    num_errors: int
    request_id: str
    delay: int


class Old(TypedDict):
    """The last successfully synced state of an object."""

    id: int
    obj_id: str
    udm_module: str
    dn: str
    attrs: dict[str, Any]
    request_id: str


class Relation(TypedDict):
    """A relation between two objects, maintained by the callback."""

    id: int
    src_obj_id: str
    src_udm_module: str
    dst_obj_id: str
    dst_udm_module: str
    relation_name: str


class Consumer(Protocol):
    """The ``consumer`` passed to ``run``: reads CCF's database, buffers writes.

    Reads raise ``CcfDatabaseError`` when CCF's database fails. Writes are
    applied together with the result, and only for results that commit.
    A unit test can pass any object with these methods.
    """

    def get_old(self, obj_id: str) -> Old | None: ...

    def get_old_by_dn(self, dn: str) -> Old | None: ...

    def lookup_old(self, field_name: str, value: str) -> list[Old]: ...

    def get_relations(self, dst_obj_id: str, relation_name: str) -> list[Relation]: ...

    def add_relation(
        self, src_obj_id: str, src_udm_module: str, dst_obj_id: str, dst_udm_module: str, relation_name: str
    ) -> Relation: ...

    def remove_relations(self, src_obj_id: str, relation_name: str) -> None: ...

    def enqueue(self, obj_id: str) -> None: ...


_F = TypeVar("_F", bound=Callable[..., Any])


class Registry:
    """The connector's functions, registered with the decorators of ``register``.

    Each decorator may be used once per process (a second use raises
    ``RuntimeError``), takes a plain ``def`` (``async def`` and non-callables
    raise ``TypeError``) and returns the function unchanged, so unit tests can
    call it directly.
    """

    __slots__ = ("_callback", "_setup", "_shutdown")

    def __init__(self) -> None:
        self._callback: Callable[[Consumer, Task], CallbackResult] | None = None
        self._setup: Callable[[], object] | None = None
        self._shutdown: Callable[[], object] | None = None

    def callback(self, function: _F) -> _F:
        """Register ``function(consumer, task) -> CallbackResult``, called once per task. Required."""
        return self._set("_callback", "callback", function)

    def setup(self, function: _F) -> _F:
        """Register ``function()``, called once after the import, before the first task.

        If it raises, CCF logs the error and calls it again after
        ``SETUP_RETRY_INTERVAL`` seconds; no task runs until it succeeds.
        """
        return self._set("_setup", "setup", function)

    def shutdown(self, function: _F) -> _F:
        """Register ``function()``, called once on a graceful shutdown after the last task.

        Only if ``setup`` succeeded (or none is registered). Errors are logged.
        """
        return self._set("_shutdown", "shutdown", function)

    def _set(self, slot: str, name: str, function: _F) -> _F:
        if not callable(function):
            raise TypeError(f"the {name} function must be callable, not {type(function).__name__}")
        if inspect.iscoroutinefunction(function):
            raise TypeError(f"the {name} function must be a plain def; run async code inside it with asyncio.run")
        registered = getattr(self, slot)
        if registered is not None:
            raise RuntimeError(f"a {name} function is already registered: {registered!r}")
        setattr(self, slot, function)
        return function

    # CCF clears the registry before it imports the connector module.
    def _clear(self) -> None:
        self._callback = self._setup = self._shutdown = None


register = Registry()
